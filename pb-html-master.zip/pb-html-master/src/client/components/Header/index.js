import React from 'react';

const Header = (props) => {
  return <header>Bot Chat</header>
};

export default Header;
