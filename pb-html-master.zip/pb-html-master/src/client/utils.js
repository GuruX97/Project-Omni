export function scrollDown(el) {
  el.scrollTop = el.scrollHeight;
}
